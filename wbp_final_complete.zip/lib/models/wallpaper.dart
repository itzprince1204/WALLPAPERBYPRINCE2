class WallpaperModel {
  final String id;
  final String url;
  final String thumb;
  WallpaperModel({required this.id, required this.url, required this.thumb});
}
