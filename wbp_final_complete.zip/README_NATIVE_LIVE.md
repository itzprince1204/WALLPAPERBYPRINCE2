Native live wallpaper instructions are included in the original README. Ask if you need the Android native template.
