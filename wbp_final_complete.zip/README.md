WALLPAPER BY PRINCE - Ready-to-build Flutter project
---------------------------------------------------

This is a ready scaffold for the 'WALLPAPER BY PRINCE' app.

What to do next:
1) Add your Pexels API key in lib/services/api_service.dart (pexelsKey variable).
2) Put local static wallpapers into assets/images/ (organize by category folders).
3) Put live mp4/webm files into assets/live/ (optional).
4) Update pubspec.yaml if you add many asset files.
5) Upload project to GitHub (create repository) and push all files.
6) Run GitHub Actions workflow (.github/workflows/build.yml) to get APK.

